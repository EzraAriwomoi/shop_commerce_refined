// eslint-disable-next-line no-unused-vars
import React from "react";
import "./style.css";

export const Frame = () => {
  return (
    <a href="#"><button className="frame">New</button></a>
  );
};
export const Frame2 = () => {
  return (
    <a href="#"><button className="frame2">Popular</button></a>
  );
};