import "../../css/homepagecss/homepage.css";

const HMCategories = () => {
  return (
    <div className="home-catergories">
      <h3>Explore our catergories</h3>
      <ul>
        <a href="#" className="flex">
          <li>Necklace</li>
        </a>
        <a href="#" className="flex">
          <li>Rings</li>
        </a>
        <a href="#" className="flex">
          <li>Bracelets</li>
        </a>
        <a href="#" className="flex">
          <li>Necklace</li>
        </a>
        <a href="#" className="flex">
          <li>Rings</li>
        </a>
      </ul>
    </div>
  );
};

export default HMCategories;
